var express = require('express')
var app = express()
var connection = require("./connection.js") //Sono i topic
var socket = require("socket.io")

var server = app.listen(3000, () => {
    console.log("Listening on port 3000");
})

var socketIo = socket(server, {
  cors: {
    origin: '*',
  }
});

socketIo.on('connection', (socket) => {

    console.log("Connection has been created with: " + socket.id);

    //Ascolto sul topic
    socket.on(connection.setParam, (newData) => {
      //Setto i prametri della box
      //.....

      console.log("Box parameter: " + newData)
      //Invio sul topic
      socketIo.sockets.emit(connection.setParam, "Ho settato i parametri della box: " + newData) //Avviso che ho settato i prametri
    });

    //Inizio l'acquistizione
    socket.on(connection.startAcquisition, (newData) => {
        console.log("Acquisition Started !")

        //Invio gli alert quando serve
        socketIo.sockets.emit(connection.startAcquisition, "Acquisizione partita")
        socketIo.sockets.emit(connection.startAcquisition, "Alert durante la corsa")
    });

    //Fine Acquisizione
    socket.on(connection.stopAcquisition, (newData) => {
      console.log("Acquisition Stopped")
      //Invio sul topic
      socketIo.sockets.emit(connection.stopAcquisition, "Acquisition Stopped") //Avviso che ho finito l'acquisizione
    });

})