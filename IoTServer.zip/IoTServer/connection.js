module.exports = {
    setParam: 'topic_setParam',
    startAcquisition: 'topic_startAcquisition',
    stopAcquisition: 'topic_stopAcquisition'
}